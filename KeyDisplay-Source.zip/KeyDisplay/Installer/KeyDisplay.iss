; Build the app first, then compile this script with Inno Setup 6.
#define AppName "KeyDisplay"
#define AppVersion "1.0.0"
#define PublishDir "..\KeyDisplay\bin\Release\net8.0-windows\win-x64\publish"

[Setup]
AppId={{B3D7A1B4-8D22-4D7A-8D9A-0F4B17E1C101}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\KeyDisplay
DefaultGroupName=KeyDisplay
OutputDir=.
OutputBaseFilename=KeyDisplay-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\KeyDisplay.exe

[Files]
Source: "{#PublishDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\KeyDisplay"; Filename: "{app}\KeyDisplay.exe"
Name: "{autodesktop}\KeyDisplay"; Filename: "{app}\KeyDisplay.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; Flags: unchecked

[Run]
Filename: "{app}\KeyDisplay.exe"; Description: "Запустить KeyDisplay"; Flags: postinstall nowait skipifsilent
