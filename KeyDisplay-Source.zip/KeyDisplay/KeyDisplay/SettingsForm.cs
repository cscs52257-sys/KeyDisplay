using System.Drawing;

namespace KeyDisplay;

public sealed class SettingsForm : Form
{
    private readonly AppSettings _settings;
    private readonly NumericUpDown _fontSize = new() { Minimum = 12, Maximum = 48, Width = 100 };
    private readonly NumericUpDown _opacity = new() { Minimum = 35, Maximum = 100, Width = 100 };
    private readonly TextBox _textColor = new() { Width = 100 };
    private readonly TextBox _background = new() { Width = 100 };
    private readonly CheckBox _topMost = new() { Text = "Поверх других окон" };
    private readonly CheckedListBox _keys = new() { CheckOnClick = true, Width = 190, Height = 230 };

    private static readonly string[] KeyOptions =
    {
        "W","A","S","D","SPACE","SHIFT","CTRL","ALT","UP","DOWN","LEFT","RIGHT",
        "ENTER","ESC","TAB","BACKSPACE","DELETE","PGUP","PGDN","HOME","END",
        "0","1","2","3","4","5","6","7","8","9",
        "F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12"
    };

    public SettingsForm(AppSettings settings)
    {
        _settings = settings;
        Text = "Настройки KeyDisplay";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        Width = 500;
        Height = 440;

        _fontSize.Value = Math.Clamp(settings.FontSize, 12, 48);
        _opacity.Value = Math.Clamp(settings.OpacityPercent, 35, 100);
        _textColor.Text = settings.TextColor;
        _background.Text = settings.BackgroundColor;
        _topMost.Checked = settings.AlwaysOnTop;

        foreach (var key in KeyOptions)
        {
            int index = _keys.Items.Add(key);
            _keys.SetItemChecked(index, settings.AllowedKeys.Contains(key));
        }

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(12), ColumnCount = 2, RowCount = 6 };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        layout.Controls.Add(new Label { Text = "Клавиши для отображения:", AutoSize = true }, 0, 0);
        layout.Controls.Add(_keys, 0, 1);
        var right = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        right.Controls.Add(new Label { Text = "Размер текста (12–48):", AutoSize = true });
        right.Controls.Add(_fontSize);
        right.Controls.Add(new Label { Text = "Непрозрачность (35–100%):", AutoSize = true, Margin = new Padding(0, 12, 0, 0) });
        right.Controls.Add(_opacity);
        right.Controls.Add(new Label { Text = "Цвет текста (#RRGGBB):", AutoSize = true, Margin = new Padding(0, 12, 0, 0) });
        right.Controls.Add(_textColor);
        right.Controls.Add(new Label { Text = "Цвет фона (#RRGGBB):", AutoSize = true, Margin = new Padding(0, 12, 0, 0) });
        right.Controls.Add(_background);
        right.Controls.Add(_topMost);
        layout.Controls.Add(right, 1, 1);
        layout.SetRowSpan(right, 3);

        var save = new Button { Text = "Сохранить", DialogResult = DialogResult.OK, Width = 100 };
        var cancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 100 };
        var bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, FlowDirection = FlowDirection.RightToLeft };
        bottom.Controls.Add(cancel);
        bottom.Controls.Add(save);
        Controls.Add(layout);
        Controls.Add(bottom);
        AcceptButton = save;
        CancelButton = cancel;

        save.Click += (_, e) =>
        {
            if (!ValidColor(_textColor.Text) || !ValidColor(_background.Text))
            {
                MessageBox.Show(this, "Цвет укажи в формате #RRGGBB, например #FFFFFF.");
                DialogResult = DialogResult.None;
                return;
            }
            _settings.FontSize = (int)_fontSize.Value;
            _settings.OpacityPercent = (int)_opacity.Value;
            _settings.TextColor = _textColor.Text;
            _settings.BackgroundColor = _background.Text;
            _settings.AlwaysOnTop = _topMost.Checked;
            _settings.AllowedKeys = _keys.CheckedItems.Cast<string>().ToHashSet(StringComparer.OrdinalIgnoreCase);
        };
    }

    private static bool ValidColor(string value)
    {
        try { _ = ColorTranslator.FromHtml(value); return value.Length == 7 && value[0] == '#'; }
        catch { return false; }
    }
}
