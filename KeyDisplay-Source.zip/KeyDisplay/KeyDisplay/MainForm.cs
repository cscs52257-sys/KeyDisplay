using System.Drawing;

namespace KeyDisplay;

public sealed class MainForm : Form
{
    private readonly AppSettings _settings;
    private readonly KeyboardHook _hook = new();
    private readonly Label _keys = new();
    private readonly Label _status = new();
    private readonly Button _startStop = new();
    private readonly Button _settingsButton = new();
    private readonly System.Windows.Forms.Timer _clearTimer = new();
    private string _lastKey = "";
    private bool _closing;

    public MainForm()
    {
        _settings = SettingsStore.Load();
        Text = "KeyDisplay";
        FormBorderStyle = FormBorderStyle.FixedToolWindow;
        StartPosition = FormStartPosition.Manual;
        Location = new Point(_settings.OverlayX, _settings.OverlayY);
        TopMost = _settings.AlwaysOnTop;
        ShowInTaskbar = true;
        Width = 440;
        Height = 190;
        BackColor = ColorTranslator.FromHtml(_settings.BackgroundColor);
        Opacity = Math.Clamp(_settings.OpacityPercent, 35, 100) / 100.0;

        var title = new Label { Text = "KeyDisplay — визуализатор клавиш", Dock = DockStyle.Top, Height = 28, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(8, 0, 0, 0), ForeColor = Color.LightGray };
        _keys.Dock = DockStyle.Fill;
        _keys.Text = "Нажми «Старт», чтобы показывать клавиши";
        _keys.TextAlign = ContentAlignment.MiddleCenter;
        _keys.Font = new Font("Segoe UI", Math.Clamp(_settings.FontSize, 12, 48), FontStyle.Bold);
        _keys.ForeColor = ColorTranslator.FromHtml(_settings.TextColor);
        _status.Text = "Захват выключен";
        _status.Dock = DockStyle.Bottom;
        _status.Height = 24;
        _status.TextAlign = ContentAlignment.MiddleLeft;
        _status.Padding = new Padding(8, 0, 0, 0);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(6, 4, 0, 0) };
        _startStop.Text = "Старт";
        _startStop.Width = 90;
        _startStop.Click += (_, _) => ToggleCapture();
        _settingsButton.Text = "Настройки";
        _settingsButton.Width = 100;
        _settingsButton.Click += (_, _) => OpenSettings();
        var hide = new Button { Text = "Свернуть", Width = 90 };
        hide.Click += (_, _) => Hide();
        buttons.Controls.AddRange(new Control[] { _startStop, _settingsButton, hide });

        Controls.Add(_keys);
        Controls.Add(buttons);
        Controls.Add(_status);
        Controls.Add(title);

        _hook.KeyPressed += OnKeyPressed;
        _clearTimer.Interval = 900;
        _clearTimer.Tick += (_, _) => { _keys.Text = ""; _clearTimer.Stop(); };
        FormClosing += (_, _) =>
        {
            _closing = true;
            _hook.Dispose();
            _clearTimer.Dispose();
            try { SettingsStore.Save(_settings); } catch { }
        };
        Move += (_, _) =>
        {
            if (WindowState == FormWindowState.Normal)
            {
                _settings.OverlayX = Left;
                _settings.OverlayY = Top;
            }
        };
    }

    private void ToggleCapture()
    {
        if (_hook.IsRunning)
        {
            _hook.Stop();
            _startStop.Text = "Старт";
            _status.Text = "Захват выключен";
            _status.ForeColor = Color.LightGray;
        }
        else
        {
            try
            {
                _hook.Start();
                _startStop.Text = "Стоп";
                _status.Text = "● Захват включён — события не сохраняются";
                _status.ForeColor = Color.LightGreen;
                Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "KeyDisplay", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    private void OnKeyPressed(string key)
    {
        if (_closing || IsDisposed) return;
        try
        {
            BeginInvoke(new Action(() =>
            {
                if (!_hook.IsRunning || !_settings.AllowedKeys.Contains(key)) return;
                _lastKey = key;
                _keys.Text = key;
                _clearTimer.Stop();
                _clearTimer.Start();
            }));
        }
        catch { }
    }

    private void OpenSettings()
    {
        using var dialog = new SettingsForm(_settings);
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            BackColor = ColorTranslator.FromHtml(_settings.BackgroundColor);
            Opacity = Math.Clamp(_settings.OpacityPercent, 35, 100) / 100.0;
            _keys.Font = new Font("Segoe UI", Math.Clamp(_settings.FontSize, 12, 48), FontStyle.Bold);
            _keys.ForeColor = ColorTranslator.FromHtml(_settings.TextColor);
            TopMost = _settings.AlwaysOnTop;
            try { SettingsStore.Save(_settings); }
            catch (Exception ex) { MessageBox.Show(this, "Не удалось сохранить настройки: " + ex.Message); }
        }
    }
}
