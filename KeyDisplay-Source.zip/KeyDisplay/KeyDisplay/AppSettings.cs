namespace KeyDisplay;

public sealed class AppSettings
{
    public int OverlayX { get; set; } = 80;
    public int OverlayY { get; set; } = 80;
    public int FontSize { get; set; } = 22;
    public int OpacityPercent { get; set; } = 92;
    public string TextColor { get; set; } = "#FFFFFF";
    public string BackgroundColor { get; set; } = "#202020";
    public bool AlwaysOnTop { get; set; } = true;
    public HashSet<string> AllowedKeys { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        "W", "A", "S", "D", "SPACE", "SHIFT", "CTRL", "ALT", "UP", "DOWN", "LEFT", "RIGHT"
    };
}
