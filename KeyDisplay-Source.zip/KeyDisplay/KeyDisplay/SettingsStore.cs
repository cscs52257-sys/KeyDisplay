using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace KeyDisplay;

public static class SettingsStore
{
    private static readonly string SettingsPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KeyDisplay", "settings.dat");

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsPath)) return new AppSettings();
            byte[] encrypted = File.ReadAllBytes(SettingsPath);
            byte[] plain = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
            return JsonSerializer.Deserialize<AppSettings>(plain) ?? new AppSettings();
        }
        catch
        {
            // If settings are unreadable/corrupt, start with safe defaults.
            return new AppSettings();
        }
    }

    public static void Save(AppSettings settings)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
        byte[] plain = JsonSerializer.SerializeToUtf8Bytes(settings, new JsonSerializerOptions { WriteIndented = true });
        byte[] encrypted = ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser);
        string temp = SettingsPath + ".tmp";
        File.WriteAllBytes(temp, encrypted);
        File.Move(temp, SettingsPath, true);
        CryptographicOperations.ZeroMemory(plain);
    }
}
