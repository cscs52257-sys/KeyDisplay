using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace KeyDisplay;

// Global low-level hook. It observes key-down events only while the user has
// explicitly enabled capture. It never stores or transmits key events.
public sealed class KeyboardHook : IDisposable
{
    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_SYSKEYDOWN = 0x0104;
    private readonly HookProc _proc;
    private IntPtr _hook = IntPtr.Zero;
    public event Action<string>? KeyPressed;

    public KeyboardHook() => _proc = HookCallback;

    public bool IsRunning => _hook != IntPtr.Zero;

    public void Start()
    {
        if (IsRunning) return;
        using Process process = Process.GetCurrentProcess();
        using ProcessModule module = process.MainModule!;
        _hook = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle(module.ModuleName), 0);
        if (_hook == IntPtr.Zero)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Не удалось включить перехват клавиш.");
    }

    public void Stop()
    {
        if (_hook == IntPtr.Zero) return;
        UnhookWindowsHookEx(_hook);
        _hook = IntPtr.Zero;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN))
        {
            int vk = Marshal.ReadInt32(lParam);
            string name = KeyName(vk);
            if (!string.IsNullOrEmpty(name))
            {
                try { KeyPressed?.Invoke(name); } catch { /* Never break the hook chain. */ }
            }
        }
        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    private static string KeyName(int vk) => vk switch
    {
        0x20 => "SPACE",
        0x10 or 0xA0 or 0xA1 => "SHIFT",
        0x11 or 0xA2 or 0xA3 => "CTRL",
        0x12 or 0xA4 or 0xA5 => "ALT",
        0x25 => "LEFT",
        0x26 => "UP",
        0x27 => "RIGHT",
        0x28 => "DOWN",
        0x0D => "ENTER",
        0x1B => "ESC",
        0x09 => "TAB",
        0x08 => "BACKSPACE",
        0x2E => "DELETE",
        0x21 => "PGUP",
        0x22 => "PGDN",
        0x24 => "HOME",
        0x23 => "END",
        >= 0x30 and <= 0x39 => ((char)vk).ToString(),
        >= 0x41 and <= 0x5A => ((char)vk).ToString(),
        >= 0x60 and <= 0x69 => "NUM" + (vk - 0x60),
        >= 0x70 and <= 0x7B => "F" + (vk - 0x6F),
        _ => ""
    };

    public void Dispose() => Stop();

    private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);
}
